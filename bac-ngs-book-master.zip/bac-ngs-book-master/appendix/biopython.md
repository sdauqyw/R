## Biopython

[biopython][] 是 python 语言的专门生物信息程序包。

#### 安装 biopython

```
~$ sudo apt-get install virtualenv virtualenv_wrapper
~$ mkvirtualenv bio
~$ workon bio
(bioS)~$ pip install biopython numpy reportlab
```


#### Reference
1. http://biopython.org/DIST/docs/
2. https://github.com/bigwiv/Biopython-cn

[biopython]: http://www.biopython.org/ "Biopython"
[python]: http://www.python.org/ "Python"
