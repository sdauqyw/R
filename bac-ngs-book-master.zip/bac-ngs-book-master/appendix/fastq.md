## Fastq 文件格式

```
@SEQ_ID
ACACGGCAGT
+SEQ_ID
A=<DFC?5DC
```
