## Python

#### enumerate

```python
dlist = ["abc", "def", "gh", "zzz"]

for index, d in enumerate(dlist):
    print("string number {} is {}".format(index,d))
```

```
# print output
string number 0 is abc
string number 1 is def
string number 2 is gh
string number 3 is zzz
```

#### set
