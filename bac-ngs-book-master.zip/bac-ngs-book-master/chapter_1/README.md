## 基因组数据处理

* [公共数据库的测序数据](sra.md)
* [去除接头](trim.md)
* [QC](qc.md)
* [序列拼接](assembly.md)
* [拼接软件评估](assemble_report.md)
* [基因组注释](annotation.md)
* [可视化基因组](visulization.md)