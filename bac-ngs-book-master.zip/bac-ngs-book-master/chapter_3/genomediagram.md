## GenomeDiagram

GenomeDiagram 现在作为整合在 Biopython 中的一个模块，可以很方便的为我们绘制比较基因组关系的图示，帮助我们可视化查看结果，


