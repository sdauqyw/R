# ViroCap

ViroCap 是2015年 [Washington University in St. Louis](http://wustl.edu) 大学研究人员开发的用于人与动物感染性病毒元基因组测序项目，其敏感度据说可以达到 PCR 方法检测病毒的程度。

## Reference

