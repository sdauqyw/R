## 专题

1. NGS 那点事
2. R 语言应用
3. Galaxy 本地化设置
4. Amazon EC2 教程
5. Circos 教程
6. Automation Pipeline Framework