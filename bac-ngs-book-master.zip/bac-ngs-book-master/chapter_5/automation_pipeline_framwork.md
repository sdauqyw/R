# Automation Pipeline Framwork

* snakelik
* Rufus
* Bpipe
* NEAT




## Reference
1. [Workflow management software for pipeline development in NGS](https://www.biostars.org/p/115745/)
2. [NEAT: a framework for building fully automated NGS pipelines and analyses](http://bmcbioinformatics.biomedcentral.com/articles/10.1186/s12859-016-0902-3)
3. [Awesome Pipeline](https://github.com/pditommaso/awesome-pipeline)