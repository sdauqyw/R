## 序列比对

* [Blast]()
* [mafft]()


#### Local Alignment

#### Global Alignment

#### Whole Genome Alignment