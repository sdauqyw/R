## 基因组注释软件

* [Prokka](prokka.md)
* [GeneMakerS](genemakers.md)
