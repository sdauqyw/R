## Artemis

[Artemis][] 是一个由 [Sanger Institute][] 中心开发的老牌图形化的基因组浏览和注释工具。这个软件历史比较悠久，从，目前最新版本号 v16.0.11 就可见其更新程度。[Artemis][] 是基于 [Java] 开发的工具，在 [Sanger Institute][] 官方网站上有一些资料，不过国内关于 [Artemis][] 的中文资料非常少。

#### 1. 用 Artemis 做细菌基因组注释




[Artemis]: http://www.sanger.ac.uk/resources/software/artemis "Artemis: Genome Browser and Annotation Tool"
[Sanger Institute]: http://www.sanger.ac.uk/ "Sanger Institute"
[Java]: http://www.oracle.com/technetwork/java/index.html "Java"
