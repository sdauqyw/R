## bwa

bwa 是 Li heng 开发的一款序列快速 mapping 的软件。

#### 下载与安装

```
~tmp$ wget http://jaist.dl.sourceforge.net/project/bio-bwa/bwa-0.7.12.tar.bz2
~tmp$ tar jxf bwa-0.7.12.tar.bz2 -C ~/app
~tmp$ cd ~/app/bwa-0.7.12
~app$ make
~app$ echo 'PATH=$PATH:~/app/bwa-0.7.12' >> ~/.bashrc
~app$ source ~/.bashrc
```

#### 使用
