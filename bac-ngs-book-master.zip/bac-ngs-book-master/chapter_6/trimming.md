## Trimming

本节主要介绍用来操作和处理 Fastq 和 Fasta 文件的各类软件和命令行程序。

* [Fastx_toolkit](fastxtoolkit.md)
* [Trimmomatic](trimmomatic.md)
* [Seqtk](seqtk.md)
