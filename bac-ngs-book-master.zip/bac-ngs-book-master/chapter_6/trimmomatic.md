## Trimmomatic

**安装 Trimmomatic**

软件安装很简单，直接下载 Trimmomatic 的软件包解压缩即可使用。
```
~/tmp$ wget http://www.usadellab.org/cms/uploads/supplementary/Trimmomatic/Trimmomatic-0.32.zip
~/tmp$ unzip Trimmomatic-0.32.zip -d ~/app
```

**使用 Trimmomatic**

Trimmomatic 的主要参数如下：

```
```