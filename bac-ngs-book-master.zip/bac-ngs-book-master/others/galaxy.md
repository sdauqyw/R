## Galaxy 本地化配置

#### Reference

1. https://wiki.galaxyproject.org/
2. http://www.chenlianfu.com/?p=1469
3. http://methdb.univ-perp.fr/cgrunau/methods/Galaxy_production_mode_installation_walkthrough.html
