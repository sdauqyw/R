## Genome Sequencing

#### illumina

1. 原理
2. 方法
3. 操作流程

#### Pacbio

